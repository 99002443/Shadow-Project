
import React from 'react';
import './App.css';
import PieChart from './components/PieChart';
import  { CreationTable } from './components/CreationTable';

function App() {
  return (
    <div className="App">
     <div className='chart'>
      <PieChart/>
      </div>
      <div className='table'>
      <CreationTable/>
      
      </div>
      
      
      
      

      
    
    
       
     
    </div>
    
    
  );
}

export default App;
