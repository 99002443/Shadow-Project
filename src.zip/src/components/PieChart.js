import React from 'react'
import {Pie} from 'react-chartjs-2'
function PieChart(){
    const data = {
        labels:['EventAt','Location','Status','EventType'],
        datasets:[
            {
                label:'Employee Information',
                backgroundColor: [
                    '#B21F00',
                    '#C9DE00',
                    '#2FDE00',
                    '#00A6B4',
                    '#6800B4'
                  ],
                  hoverBackgroundColor: [
                  '#501800',
                  '#4B5000',
                  '#175000',
                  '#003350',
                  '#35014F'
                  ],
                data: [11,22,33,44]
            }
        ]
    }
    return(
        <div>
            <Pie data={data}
            options={{
            
                title:{
                  display:true,
                  text:'Employee Status',
                  fontSize:20
                },
                legend:{
                  display:true,
                  position:'bottom'
                }
              }}
            />

        </div>
    )
}
export default PieChart